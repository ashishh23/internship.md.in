import React from 'react'
import "./team.css"

import ashu1 from "../MDteam/img/Ashu1.jpg";

export default function Ashish() {
  return (
<>
  <meta charSet="UTF-8" />
  <meta httpEquiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
 
  {/* Font cdn */}
  <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"
  />
  {/* Css file */}
  <link rel="stylesheet" href="team.css" />
  
  <header>
    <div className="user">
    <img src={ashu1} alt="Profile_ashish"  />
    
      <h3 className="name">Ashish Kothwal</h3>
      <p className="post">Co-Founder & CEO </p>
    </div>
    {/* <nav className="navbar">
      <ul>
        <li>
          <a href="#home">HOME</a>
        </li>
        <li>
          <a href="#about">ABOUT</a>
        </li>
        <li>
          <a href="#education">EDUCATION</a>
        </li>
        <li>
          <a href="#portfolio">PORTFOLIO</a>
        </li>
        <li>
          <a href="#contact">CONTACT ME</a>
        </li>
      </ul>
    </nav> */}
  </header>
  {/* Home section */}
  <section className="home" id="home">
    <h3>HI THERE !</h3>
    <h1>
      I'M <span>Ashish Kothwal</span>
    </h1>
    <p>
    “A designer knows he has achieved perfection not when there is nothing left to add, but when there is nothing left to take away.”{" "}
    </p>
    <a href="#about">
      <button className="btn">
        About Me
        <i className="main" />
      </button>
    </a>
  </section>
  {/* About section  */}
  <section className="about" id="about">
    <div className="heading">
      <span>About</span>Me
    </div>
    <div className="row">
      <div className="info">
        <h3>
          <span>name:</span>Sneha Kute
        </h3>
        <h3>
          {" "}
          <span> age : </span> 21{" "}
        </h3>
        <h3>
          {" "}
          <span> qualification : </span> BE Pursuing{" "}
        </h3>
        <h3>
          {" "}
          <span> Year : </span>Third year{" "}
        </h3>
        <h3>
          {" "}
          <span> Interest : </span> Front End{" "}
        </h3>
        <a href="#">
          <button className="btn">Download CV</button>
        </a>
      </div>
      <div className="counter">
        <div className="box">
          <span>+</span>
          <h3>Fresher</h3>
        </div>
        <div className="box">
          <span>2</span>
          <h3>porject completed</h3>
        </div>
        <div className="box">
          <span>1</span>
          <h3>Internship completed</h3>
        </div>
        <div className="box">
          <span>2</span>
          <h3>Course completed</h3>
        </div>
      </div>
    </div>
  </section>
  {/* education section starts  */}
  <section className="education" id="education">
    <h1 className="heading">
      My<span>Education</span>
    </h1>
    <div className="box-container">
      <div className="box">
        <span>SSC</span>
        <h3>Percent:88.20%</h3>
        <p>VPVAmbikanagar</p>
      </div>
      <div className="box">
        <span>HSC</span>
        <h3>Percent:65.08%</h3>
        <p>VPVAmbikanagar</p>
      </div>
      <div className="box">
        <span>Diploma[IT]</span>
        <h3>Percent:88.06</h3>
        <p> Government Polytechnic Ambad</p>
      </div>
      <div className="box">
        <span>Internship</span>
        <h3>Bitlanace Tech Hub(Aurangabad)</h3>
        <p>Domain:Web development using php</p>
      </div>
      <div className="box">
        <span>BE</span>
        <h3>Third Year Pursuing</h3>
        <p>SE Percent:7.8%</p>
        <p></p>
        <p>Pravara Rural Engineering College Loni</p>
      </div>
      <div className="box">
        <i />
        <span>Internship</span>
        <h3>SachiTech(Nashik)</h3>
        <p>Web design/Development</p>
      </div>
    </div>
  </section>
  <section className="portfolio" id="portfolio">
    <h1 className="heading">
      {" "}
      My <span>portfolio</span>{" "}
    </h1>
    <div className="box-container">
      <div className="box">
        <img src="img/img1.jpg" alt="" />
      </div>
      <div className="box">
        <img src="img/img2.jpg" alt="" />
      </div>
      <div className="box">
        <img src="img/img3.jpg" alt="" />
      </div>
      <div className="box">
        <img src="img/img4.jpg" alt="" />
      </div>
      <div className="box">
        <img src="img/img5.jpg" alt="" />
      </div>
      <div className="box">
        <img src="img/img6.jpg" alt="" />
      </div>
    </div>
  </section>
  {/* contact section starts  */}
  <section className="contact" id="contact">
    <h1 className="heading">
      {" "}
      <span>contact</span> me{" "}
    </h1>
    <div className="row">
      <div className="content">
        <h3 className="title">Contact Information</h3>
        <div className="info">
          <h3> kutesneha0@gmail.com </h3>
          <h3> +9119517317 </h3>
          <h3> +9226428756 </h3>
          <h3> Nevasa, A.nagar - 414306. </h3>
        </div>
      </div>
      <form action="">
        <input type="text" placeholder="Name" className="box" />
        <input type="email" placeholder="email" className="box" />
        <input type="text" placeholder="project" className="box" />
        <textarea
          name=""
          id=""
          cols={30}
          rows={10}
          className="box message"
          placeholder="message"
          defaultValue={""}
        />
        <button type="submit" className="btn">
          Send
        </button>
      </form>
    </div>
  </section>
</>

  )
}
