import React from 'react'
import { Link } from "react-router-dom";
import logo from "../logo.png";
export default function ISFooter() {
  return (
   <>
   <div className="footer-dec">
    <img src="assets/images/footer-dec.png" alt="" />
  </div>
  <footer>
    <div className="container">
      <div className="row">
        <div className="col-lg-3">
          <div className="about footer-item">
            <div className="logo">
            <Link to="/" className="navbar-brand" ><img src={logo} alt="logo" style={{"width":"100px"}} /></Link>
            <h4>Miracle Developers</h4>
            </div>
            <a href="#">contact@miracledevelopers.in</a>
            <ul>
              <li>
                <a href="#">
                  <i className="fa fa-facebook" />
                </a>
              </li>
              <li>
                <a href="#">
                  <i className="fa fa-twitter" />
                </a>
              </li>
              <li>
                <a href="#">
                  <i className="fa fa-behance" />
                </a>
              </li>
              <li>
                <a href="#">
                  <i className="fa fa-instagram" />
                </a>
              </li>
            </ul>
          </div>
        </div>
        <div className="col-lg-3">
          <div className="services footer-item">
            <h4>Useful Links</h4>
            <ul>
              <li>
                <a href="#">Home</a>
              </li>
              <li>
                <a href="#">About us</a>
              </li>
              <li>
                <a href="#">Internship Domains</a>
              </li>
              <li>

                <a href="#">Apply Now</a>
              </li>
            </ul>
          </div>
        </div>
        <div className="col-lg-3">
          <div className="community footer-item">
            <h4>Internship Domains</h4>
            <ul>
              <li>
                <a href="#portfolio">Data Science</a>
              </li>
              <li>
                <a href="#portfolio">Python Development</a>
              </li>
              <li>
                <a href="#portfolio">Website Checkup</a>
              </li>
              <li>
                <a href="#portfolio">Graphic Design</a>
              </li>
            </ul>
          </div>
        </div>
        <div className="col-lg-3">
          <div className="subscribe-newsletters footer-item">
            <h4>Start learning today</h4>
            <p>Build work experience which helps you break top tech jobs and internships.</p>
            <br />
            
            <div className="main-red-button-hover">
            <Link to="/Ashish" className="navbar-brand" >ashish Login</Link>
         
                {/* <a href="#portfolio">Apply Now</a> */}
              </div>
          </div>
        </div>
        <div className="col-lg-12">
            <div className="copyright">
                <p>
                Copyright © 2023 Miracle Developers Co. All Rights Reserved.
                <br />
                Designed by{" "}
                <a
                  
                    href="https://www.miracledevelopers.in/"
                    title="free CSS templates"
                    target={'_blank'}
                    rel="noreferrer"
                >
                    Miracle Developers
                </a>
                </p>
            </div>
        </div>
      </div>
    </div>
  </footer>
   
   
   </>
  )
}
