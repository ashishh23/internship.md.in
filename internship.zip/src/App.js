import React from 'react'
import { Link } from "react-router-dom";
import ISFooter from './components/ISFooter';
import ISHeader from "./components/ISHeader";

export default function App() {
  return (
    <>


      {/* ***** Preloader Start ***** */}
      {/* <div id="js-preloader" className="js-preloader">
    <div className="preloader-inner">
      <span className="dot" />
      <div className="dots">
        <span />
        <span />
        <span />
      </div>
    </div>
  </div> */}
      {/* ***** Preloader End ***** */}

      <ISHeader />

      <div className="main-banner" id="top">
        <div className="container">
          <div className="row">
            <div className="col-lg-12">
              <div className="row">
                <div className="col-lg-6 align-self-center">
                  <div className="owl-carousel owl-banner">
                    <div className="item header-text">
                      <h6>Welcome to miracle Developers</h6>
                      <h2>
                        Build <em>your website</em> the best in <span>SEO</span>?
                      </h2>
                      <p>
                        This is a professional looking HTML Bootstrap 5 website
                        template brought to you by TemplateMo website.
                      </p>
                      <div className="down-buttons">
                        <div className="main-blue-button-hover">
                          <a href="#contact">Message Us Now</a>
                        </div>
                        <div className="call-button">
                          <a href="#">
                            <i className="fa fa-phone" /> +91 8965902893
                          </a>
                        </div>
                      </div>
                    </div>
                    <div className="item header-text">
                      <h6>Online Marketing</h6>
                      <h2>
                        Get the <em>best ideas</em> for <span>your website</span>
                      </h2>
                      <p>
                        You are NOT allowed to redistribute this template ZIP file
                        on any Free CSS collection websites. Contact us for more
                        info. Thank you.
                      </p>
                      <div className="down-buttons">
                        <div className="main-blue-button-hover">
                          <a href="#services">Our Services</a>
                        </div>
                        <div className="call-button">
                          <a href="#">
                            <i className="fa fa-phone" /> +91 9370454334
                          </a>
                        </div>
                      </div>
                    </div>
                    <div className="item header-text">
                      <h6>Video Tutorials</h6>
                      <h2>
                        Watch <em>our videos</em> for your <span>projects</span>
                      </h2>
                      <p>
                        Please{" "}
                        <a
                          rel="nofollow"
                          href="https://www.paypal.me/templatemo"
                          target="_blank"
                        >
                          support us
                        </a>{" "}
                        a little via PayPal if this digital marketing HTML template
                        is useful for you. Thank you.
                      </p>
                      <div className="down-buttons">
                        <div className="main-blue-button-hover">
                          <a href="#video">Watch Videos</a>
                        </div>
                        <div className="call-button">
                          <a href="#">
                            <i className="fa fa-phone" /> 050-040-0320
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div id="services" className="our-services section">
        <div className="services-right-dec">
          <img src="assets/images/services-right-dec.png" alt="" />
        </div>
        <div className="container">
          <div className="services-left-dec">
            <img src="assets/images/services-left-dec.png" alt="" />
          </div>
          <div className="row">
            <div className="col-lg-6 offset-lg-3">
              <div className="section-heading">
                <h2>
                  On a mission to make learning<em> Experience</em> driven
                </h2>
                {/* <span>Our Services</span> */}
              </div>
            </div>
          </div>
          <div className="row">
            <div className="col-lg-12">
              <div className="owl-carousel owl-services">
                <div className="item">
                  <h4>Learn More about our Guidelines</h4>
                  <div className="icon">
                    <img src="assets/images/service-icon-01.png" alt="" />
                  </div>
                  <p>Feel free to use this template for your business</p>
                </div>
                <div className="item">
                  <h4>Develop The Best Strategy for Business</h4>
                  <div className="icon">
                    <img src="assets/images/service-icon-02.png" alt="" />
                  </div>
                  <p>Get to know more about the topic in details</p>
                </div>
                <div className="item">
                  <h4>UI / UX Design and Development</h4>
                  <div className="icon">
                    <img src="assets/images/service-icon-03.png" alt="" />
                  </div>
                  <p>Get to know more about the topic in details</p>
                </div>
                <div className="item">
                  <h4>Discover &amp; Explore our SEO Tips</h4>
                  <div className="icon">
                    <img src="assets/images/service-icon-04.png" alt="" />
                  </div>
                  <p>Feel free to use this template for your business</p>
                </div>
                <div className="item">
                  <h4>Optimizing your websites for Speed</h4>
                  <div className="icon">
                    <img src="assets/images/service-icon-01.png" alt="" />
                  </div>
                  <p>Get to know more about the topic in details</p>
                </div>
                <div className="item">
                  <h4>See The Strategy In The Market</h4>
                  <div className="icon">
                    <img src="assets/images/service-icon-02.png" alt="" />
                  </div>
                  <p>Get to know more about the topic in details</p>
                </div>
                <div className="item">
                  <h4>Best Content Ideas for your pages</h4>
                  <div className="icon">
                    <img src="assets/images/service-icon-03.png" alt="" />
                  </div>
                  <p>Feel free to use this template for your business</p>
                </div>
                <div className="item">
                  <h4>Optimizing Speed for your web pages</h4>
                  <div className="icon">
                    <img src="assets/images/service-icon-04.png" alt="" />
                  </div>
                  <p>Get to know more about the topic in details</p>
                </div>
                <div className="item">
                  <h4>Accessibility for mobile viewing</h4>
                  <div className="icon">
                    <img src="assets/images/service-icon-01.png" alt="" />
                  </div>
                  <p>Get to know more about the topic in details</p>
                </div>
                <div className="item">
                  <h4>Content Ideas for your next project</h4>
                  <div className="icon">
                    <img src="assets/images/service-icon-02.png" alt="" />
                  </div>
                  <p>Feel free to use this template for your business</p>
                </div>
                <div className="item">
                  <h4>UI &amp; UX Design &amp; Development</h4>
                  <div className="icon">
                    <img src="assets/images/service-icon-03.png" alt="" />
                  </div>
                  <p>Get to know more about the topic in details</p>
                </div>
                <div className="item">
                  <h4>Discover the digital marketing trend</h4>
                  <div className="icon">
                    <img src="assets/images/service-icon-04.png" alt="" />
                  </div>
                  <p>Get to know more about the topic in details</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div id="about" className="about-us section">
        <div className="container">
          <div className="row">
            <div className="col-lg-6 align-self-center">
              <div className="left-image">
                <img
                  src="assets/images/about-left-image.png"
                  alt="Two Girls working together"
                />
              </div>
            </div>
            <div className="col-lg-6">
              <div className="section-heading">
                <h2>
                  Land your dream <em>Internship</em> &amp;{" "}
                  <span> Job</span>
                </h2>
                <p>
                  Get trained, work on live projects and get hired in 4 Weeks
                </p>
                <div className="row">
                  <div className="col-lg-4">
                    <div className="fact-item">
                      <div className="count-area-content">
                        <div className="icon">
                          <img src="assets/images/service-icon-01.png" alt="" />
                        </div>
                        <div className="count-digit">1023</div>
                        <div className="count-title">Happy Interns</div>
                        <p>Meeting new students, making connections, and building relationships will all help down the line when you’re looking for a job.</p>
                      </div>
                    </div>
                  </div>
                  <div className="col-lg-4">
                    <div className="fact-item">
                      <div className="count-area-content">
                        <div className="icon">
                          <img src="assets/images/service-icon-02.png" alt="" />
                        </div>
                        <div className="count-digit">6</div>
                        <div className="count-title">Total Trainers</div>
                        <p>Motivation will get you started, while habit will keep you going.</p>
                      </div>
                    </div>
                  </div>
                  <div className="col-lg-4">
                    <div className="fact-item">
                      <div className="count-area-content">
                        <div className="icon">
                          <img src="assets/images/service-icon-03.png" alt="" />
                        </div>
                        <div className="count-digit">24 Hr.</div>
                        <div className="count-title">Hours of Support</div>
                        <p>"Happiness is a by-product of an effort to make someone else happy."</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div id="portfolio" className="our-portfolio section">
        <div className="portfolio-left-dec">
          <img src="assets/images/portfolio-left-dec.png" alt="" />
        </div>

        <div className="container-fluid">
          <div className="row">
            <div className="col-lg-12">
              <div className="owl-carousel owl-portfolio">
                <div className="item">
                  <div className="thumb">
                    <img src="assets/images/portfolio-01.jpg" alt="" />
                    <div className="hover-effect">
                      <div className="inner-content">
                        <a
                          rel="sponsored"
                          href="https://templatemo.com/tm-564-plot-listing"
                          target="_parent"
                        >
                          <h4>First Project</h4>
                        </a>
                        <span>Plot Listing</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="item">
                  <div className="thumb">
                    <img src="assets/images/portfolio-02.jpg" alt="" />
                    <div className="hover-effect">
                      <div className="inner-content">
                        <a href="#">
                          <h4>Project Two</h4>
                        </a>
                        <span>SEO &amp; Marketing</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="item">
                  <div className="thumb">
                    <img src="assets/images/portfolio-03.jpg" alt="" />
                    <div className="hover-effect">
                      <div className="inner-content">
                        <a
                          rel="sponsored"
                          href="https://templatemo.com/tm-562-space-dynamic"
                          target="_parent"
                        >
                          <h4>Third Project</h4>
                        </a>
                        <span>Space Dynamic SEO</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="item">
                  <div className="thumb">
                    <img src="assets/images/portfolio-04.jpg" alt="" />
                    <div className="hover-effect">
                      <div className="inner-content">
                        <a href="#">
                          <h4>Project Four</h4>
                        </a>
                        <span>Website Marketing</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="item">
                  <div className="thumb">
                    <img src="assets/images/portfolio-01.jpg" alt="" />
                    <div className="hover-effect">
                      <div className="inner-content">
                        <a href="#">
                          <h4>Fifth Project</h4>
                        </a>
                        <span>Digital Assets</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="item">
                  <div className="thumb">
                    <img src="assets/images/portfolio-02.jpg" alt="" />
                    <div className="hover-effect">
                      <div className="inner-content">
                        <a href="#">
                          <h4>Sixth Project</h4>
                        </a>
                        <span>SEO &amp; Marketing</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="item">
                  <div className="thumb">
                    <img src="assets/images/portfolio-03.jpg" alt="" />
                    <div className="hover-effect">
                      <div className="inner-content">
                        <a href="#">
                          <h4>7th Project</h4>
                        </a>
                        <span>SEO &amp; Marketing</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="item">
                  <div className="thumb">
                    <img src="assets/images/portfolio-04.jpg" alt="" />
                    <div className="hover-effect">
                      <div className="inner-content">
                        <a href="#">
                          <h4>8th Project</h4>
                        </a>
                        <span>SEO &amp; Marketing</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="item">
                  <div className="thumb">
                    <img src="assets/images/portfolio-01.jpg" alt="" />
                    <div className="hover-effect">
                      <div className="inner-content">
                        <a href="#">
                          <h4>9th Project</h4>
                        </a>
                        <span>SEO &amp; Marketing</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="item">
                  <div className="thumb">
                    <img src="assets/images/portfolio-02.jpg" alt="" />
                    <div className="hover-effect">
                      <div className="inner-content">
                        <a href="#">
                          <h4>Project Ten</h4>
                        </a>
                        <span>SEO &amp; Marketing</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="item">
                  <div className="thumb">
                    <img src="assets/images/portfolio-03.jpg" alt="" />
                    <div className="hover-effect">
                      <div className="inner-content">
                        <a href="#">
                          <h4>Project Eleven</h4>
                        </a>
                        <span>SEO &amp; Marketing</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="item">
                  <div className="thumb">
                    <img src="assets/images/portfolio-04.jpg" alt="" />
                    <div className="hover-effect">
                      <div className="inner-content">
                        <a href="#">
                          <h4>12th Project</h4>
                        </a>
                        <span>SEO &amp; Marketing</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div id="pricing" className="pricing-tables">
        <div className="tables-left-dec">
          <img src="assets/images/tables-left-dec.png" alt="" />
        </div>
        <div className="tables-right-dec">
          <img src="assets/images/tables-right-dec.png" alt="" />
        </div>
        <div className="container">
          <div className="row">
            <div className="col-lg-6 offset-lg-3">
              <div className="section-heading">
                <h2>
                  Select a suitable <em>Domain</em> for your Work As {" "}
                  <span>Interns</span>
                </h2>
                <span>Our Domains</span>
              </div>
            </div>
          </div>
          <div className="row ">
            <div className="col-lg-4">
              <div className="item first-item">
                <span>Data Science</span>
                {/* <em>$160/mo</em>
            <span>$140</span> */}
                <ul>
                  <li>4 Projects</li>
                  <li>Position :- Intern</li>
                  <li>Duration :- 1 Month</li>
                  <li>Location :- Remote</li>
                </ul>
                <div className="main-blue-button-hover">
                  <Link to="/RegistrationForm" >Enroll Now</Link>

                </div>
              </div>
            </div>
            <div className="col-lg-4">
              <div className="item first-item">
              <span>Python Development</span>
               
                {/* <em>$160/mo</em>
            <span>$140</span> */}
                <ul>
                  <li>4 Projects</li>
                  <li>Position :- Intern</li>
                  <li>Duration :- 1 Month</li>
                  <li>Location :- Remote</li>
                </ul>
                <div className="main-blue-button-hover">
                <Link to="/RegistrationForm" >Enroll Now</Link>
                </div>
              </div>
            </div>
            <div className="col-lg-4">
              <div className="item first-item">
                <span>Web Development</span>
                {/* <em>$160/mo</em>
            <span>$140</span> */}
                <ul>
                  <li>4 Projects</li>
                  <li>Position :- Intern</li>
                  <li>Duration :- 1 Month</li>
                  <li>Location :- Remote</li>
                </ul>
                <div className="main-blue-button-hover">
                <Link to="/RegistrationForm" >Enroll Now</Link>
                </div>
              </div>
            </div>
            <div className="col-lg-4">
              <div className="item first-item">
                <span>Android Development</span>
                {/* <em>$160/mo</em>
            <span>$140</span> */}
                <ul>
                  <li>4 Projects</li>
                  <li>Position :- Intern</li>
                  <li>Duration :- 1 Month</li>
                  <li>Location :- Remote</li>
                </ul>
                <div className="main-blue-button-hover">
                <Link to="/RegistrationForm" >Enroll Now</Link>
                </div>
              </div>
            </div>
            <div className="col-lg-4">
              <div className="item second-item">
              <span>C# & .net</span>
                {/* <em>$160/mo</em>
            <span>$140</span> */}
                <ul>
                  <li>4 Projects</li>
                  <li>Position :- Intern</li>
                  <li>Duration :- 1 Month</li>
                  <li>Location :- Remote</li>
                </ul>
                <div className="main-blue-button-hover">
                <Link to="/RegistrationForm" >Enroll Now</Link>
                </div>
              </div>
            </div>
            <div className="col-lg-4">
              <div className="item third-item">


                <span>AWS Cloud</span>
                <ul>
                  <li>4 Project</li>
                  <li>Position :- Intern</li>
                  <li>Duration :- 1 Month</li>
                  <li>Location :- Remote</li>
                </ul>
                <div className="main-blue-button-hover">
                <Link to="/RegistrationForm" >Enroll Now</Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>


      <div id="subscribe" className="subscribe">
        <div className="container">
          <div className="row">
            <div className="col-lg-12">
              <div className="inner-content">
                <div className="row">
                  <div className="col-lg-10 offset-lg-1">
                    <h2>Get in touch with us</h2>
                    <form id="subscribe" action="" method="get">
                      <input
                        type="text"
                        name="website"
                        id="website"
                        placeholder="Enter Your Doubts"
                        required=""
                      />
                      <input
                        type="text"
                        name="email"
                        id="email"
                        pattern="[^ @]*@[^ @]*"
                        placeholder="Your Email"
                        required=""
                      />
                      <button
                        type="submit"
                        id="form-submit"
                        className="main-button "
                      >
                        Submit
                      </button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div id="video" className="our-videos section">
        <div className="container">
          <div className="row">
            <div className="col-lg-6 offset-lg-3">
              <div className="section-heading">
                <h2>
                  Our Recent <em>Projects</em> &amp; Case Studies{" "}
                  <span>

                  </span>

                </h2>
                <br />
                <br />
                <span>
                  {/* // Our Portfolio */}

                </span>
              </div>
            </div>
          </div>
        </div>
        <div className="videos-left-dec">
          <img src="assets/images/videos-left-dec.png" alt="" />
        </div>
        <div className="videos-right-dec">
          <img src="assets/images/videos-right-dec.png" alt="" />
        </div>
        <div className="container">
          <div className="row">
            <div className="col-lg-12">
              <div className="naccs">
                <div className="grid">
                  <div className="row">
                    <div className="col-lg-8">
                      <ul className="nacc">
                        <li className="active">
                          <div>
                            <div className="thumb">
                              <iframe
                                width="100%"
                                height="auto"
                                src="https://www.youtube.com/embed/JynGuQx4a1Y"
                                title="YouTube video player"
                                frameBorder={0}
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                allowFullScreen=""
                              />
                              <div className="overlay-effect">
                                <a href="#">
                                  <h4>Project One</h4>
                                </a>
                                <span>SEO &amp; Marketing</span>
                              </div>
                            </div>
                          </div>
                        </li>
                        <li>
                          <div>
                            <div className="thumb">
                              <iframe
                                width="100%"
                                height="auto"
                                src="https://www.youtube.com/embed/RdJBSFpcO4M"
                                title="YouTube video player"
                                frameBorder={0}
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                allowFullScreen=""
                              />
                              <div className="overlay-effect">
                                <a href="#">
                                  <h4>Second Project</h4>
                                </a>
                                <span>Advertising &amp; Marketing</span>
                              </div>
                            </div>
                          </div>
                        </li>
                        <li>
                          <div>
                            <div className="thumb">
                              <iframe
                                width="100%"
                                height="auto"
                                src="https://www.youtube.com/embed/ZlfAjbQiL78"
                                title="YouTube video player"
                                frameBorder={0}
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                allowFullScreen=""
                              />
                              <div className="overlay-effect">
                                <a href="#">
                                  <h4>Project Three</h4>
                                </a>
                                <span>Digital &amp; Marketing</span>
                              </div>
                            </div>
                          </div>
                        </li>
                        <li>
                          <div>
                            <div className="thumb">
                              <iframe
                                width="100%"
                                height="auto"
                                src="https://www.youtube.com/embed/mx1WseE7-0Y"
                                title="YouTube video player"
                                frameBorder={0}
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                allowFullScreen=""
                              />
                              <div className="overlay-effect">
                                <a href="#">
                                  <h4>Fourth Project</h4>
                                </a>
                                <span>SEO &amp; Advertising</span>
                              </div>
                            </div>
                          </div>
                        </li>
                      </ul>
                    </div>
                    <div className="col-lg-4">
                      <div className="menu">
                        <div className="active">
                          <div className="thumb">
                            <img src="assets/images/video-thumb-01.png" alt="" />
                            <div className="inner-content">
                              <h4>Project One</h4>
                              <span>SEO &amp; Marketing</span>
                            </div>
                          </div>
                        </div>
                        <div>
                          <div className="thumb">
                            <img src="assets/images/video-thumb-02.png" alt="" />
                            <div className="inner-content">
                              <h4>Second Project</h4>
                              <span>Advertising &amp; Marketing</span>
                            </div>
                          </div>
                        </div>
                        <div>
                          <div className="thumb">
                            <img
                              src="assets/images/video-thumb-03.png"
                              alt="Marketing"
                            />
                            <div className="inner-content">
                              <h4>Project Three</h4>
                              <span>Digital &amp; Marketing</span>
                            </div>
                          </div>
                        </div>
                        <div>
                          <div className="thumb">
                            <img
                              src="assets/images/video-thumb-04.png"
                              alt="SEO Work"
                            />
                            <div className="inner-content">
                              <h4>Fourth Project</h4>
                              <span>SEO &amp; Advertising</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div id="contact" className="contact-us section">
        <div className="container">
          <div className="row">
            <div className="col-lg-7">
              <div className="section-heading">
                <h2>
                  Would You Like To <br />
                  <em>Contact</em> us
                </h2>
                <div id="map">
                  {/* <iframe
                src="https://maps.google.com/maps?q=Av.+L%C3%BAcio+Costa,+Rio+de+Janeiro+-+RJ,+Brazil&t=&z=13&ie=UTF8&iwloc=&output=embed"
                width="100%"
                height="360px"
                frameBorder={0}
                style={{ border: 0 }}
                allowFullScreen=""
              /> */}
                </div>
                <div className="info">
                  <span>
                    <i className="fa fa-phone" />{" "}
                    <a href="#">
                      +91 8965902893
                      <br />
                      +91 9370454334
                    </a>
                  </span>
                  <span>
                    <i className="fa fa-envelope" />{" "}
                    <a href="#">
                      contact@miracledevelopers.in
                      <br />
                      service@miracledevelopers.in
                    </a>
                  </span>
                </div>
              </div>
            </div>
            <div className="col-lg-5 align-self-center">
              <form id="contact" action="" method="get">
                <div className="row">
                  <div className="col-lg-12">
                    <fieldset>
                      <input
                        type="name"
                        name="name"
                        id="name"
                        placeholder="Name"
                        autoComplete="on"
                        required=""
                      />
                    </fieldset>
                  </div>
                  <div className="col-lg-12">
                    <fieldset>
                      <input
                        type="surname"
                        name="surname"
                        id="surname"
                        placeholder="Surname"
                        autoComplete="on"
                        required=""
                      />
                    </fieldset>
                  </div>
                  <div className="col-lg-12">
                    <fieldset>
                      <input
                        type="text"
                        name="email"
                        id="email"
                        pattern="[^ @]*@[^ @]*"
                        placeholder="Your Email"
                        required=""
                      />
                    </fieldset>
                  </div>
                  <div className="col-lg-12">
                    <fieldset>
                      <input
                        type="text"
                        name="website"
                        id="website"
                        placeholder="Your Message"
                        required=""
                      />
                    </fieldset>
                  </div>
                  <div className="col-lg-12">
                    <fieldset>
                      <button
                        type="submit"
                        id="form-submit"
                        className="main-button"
                      >
                        Send Message
                      </button>
                    </fieldset>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
        <div className="contact-dec">
          <img src="assets/images/contact-dec.png" alt="" />
        </div>
        <div className="contact-left-dec">
          <img src="assets/images/contact-left-dec.png" alt="" />
        </div>
      </div>
      <ISFooter />
      {/* Scripts */}
    </>

  )
}
