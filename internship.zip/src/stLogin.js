
import React from 'react'
import { Link } from "react-router-dom";
// import logo from "./logo.png";
import "./stLogin.css"

import ISFooter from './components/ISFooter'


export default function stLogin() {
  return (
    <>

 <section className='ak'>
    <div className="container" > 
    <div className="card">
      <a className="singup">Sign Up</a>
      {/* <div className="inputBox1">
        <input type="text" required="required" />
        <span className="user">Email</span>
      </div> */}
      <div className="inputBox">
        <input type="text" required="required" />
        <span>Username</span>
      </div>
      <div className="inputBox">
        <input type="password" required="required" />
        <span>Password</span>
      </div>
      {/* <Link to="/STLogin" id='enter' >Login</Link> */}

      <button className='enter'> <Link to="/STLogin" >Enter</Link></button>
    </div>
  </div>
  </section>
  <ISFooter />
  </>
  )
}
