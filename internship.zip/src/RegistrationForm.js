import React from 'react'
import { Link } from 'react-router-dom'
import ISFooter from './components/ISFooter'
import ISHeader from './components/ISHeader'
// import ISHeader from './components/ISHeader'

import logo from "../src/logo.png";


export default function RegistrationForm() {
    return (
        <>


            {/* <ISHeader />  */}
  
            <div className="container mt-3">
                <form>
                    <div className="row jumbotron box8">
                        <div className="col-sm-12 mx-t3 mb-4">
                            <h2 className="text-center" style={{color:"#ff685f"}} > <b><span>Internship Application Form</span></b></h2>
                        </div>

                        <div className="col-sm-6 form-group">
                            <label htmlFor="name-f">First Name</label>
                            <input
                                type="text"
                                className="form-control"
                                name="fname"
                                id="name-f"
                                placeholder="Enter your first name."
                                required=""
                            />
                        </div>
                        <div className="col-sm-6 form-group">
                            <label htmlFor="name-l">Last name</label>
                            <input
                                type="text"
                                className="form-control"
                                name="lname"
                                id="name-l"
                                placeholder="Enter your last name."
                                required=""
                            />
                            <br /> 
                        </div>

                        <div className="col-sm-6 form-group">
                            <label htmlFor="email">Email</label>
                            <input
                                type="email"
                                className="form-control"
                                name="email"
                                id="email"
                                placeholder="Enter your email."
                                required=""
                            />
                        </div>
                        <div className="col-sm-6 form-group">
                            <label htmlFor="address-2">College Name</label>
                            <input
                                type="text"
                                className="form-control"
                                name="College Name"
                                id="College Name"
                                placeholder="Full College Name."
                                required=""
                            />
                            <br />
                        </div>

                        <div className="col-sm-6 form-group">
                            <label htmlFor="address-1">Select Qualification</label>
                            <select className="form-control custom-select browser-default">
                                <option value="" selected>Choose</option>
                                <option value="BE">BE</option>
                                <option value="B Tech">B Tech</option>
                                <option value="Diploma">Diploma</option>
                                <option value="BCS"> BCS</option>
                                <option value="MCS">MCS</option>
                                <option value="BCA">BCA</option>
                                <option value="MCA">MCA</option>
                                <option value="BSC">BSC</option>
                            </select>
                            <br />
                        </div>

                        <div className="col-sm-4 form-group">
                            <label htmlFor="State">Stream Name</label>
                            <input
                                type="address"
                                className="form-control"
                                name="Stream Name"
                                id="Stream Name"
                                placeholder="Stream Name."
                                required=""
                            />
                            <br />
                        </div>
                        <div className="col-sm-2 form-group">
                            <label htmlFor="zip">Passing Year</label>

                            <select className="form-control custom-select browser-default">
                                <option value="" selected>Choose</option>
                                <option value="2021">2021</option>
                                <option value="2022">2022</option>
                                <option value="2023">2023</option>
                                <option value="2024">2024</option>
                                <option value="2025">2025</option>
                            </select>
                        </div>
                        <div className="col-sm-6 form-group">

                            <label htmlFor="State">Linkedin Profile Link</label>
                            <input
                                type="text"
                                className="form-control"
                                name="Linkedinlink"
                                id="Linkedinlink"
                                placeholder="Enter Linkedin Profile link"
                                required=""
                            />

                        </div>
                        <div className="col-sm-6 form-group">
                            <label for="exampleInputPassword1">Resume</label>
                            <input type="file" className="form-control" id="file" name="file" accept="application/pdf" required />
                            <br />
                        </div>
                        <div className="col-sm-6 form-group">
                            <label htmlFor="State">Github Profile Link</label>
                            <input
                                type="text"
                                className="form-control"
                                name="Githublink"
                                id="Githublink"
                                placeholder="Enter Github Profile link"
                                required=""
                            />
                        </div>
                        <div className="col-sm-2 form-group">
                            <label htmlFor="sex">Gender</label>
                            <select id="sex" className="form-control browser-default custom-select">
                                <option value="male">Male</option>
                                <option value="female">Female</option>
                                <option value="unspesified">Unspecified</option>
                            </select>
                        </div>
                        <div className="col-sm-4 form-group">
                            <label htmlFor="tel">Phone</label>
                            <input
                                type="tel"
                                name="phone"
                                className="form-control"
                                id="tel"
                                placeholder="Enter Your Contact Number."
                                required=""
                            />
                            <br />
                        </div>
                        <div className="col-sm-6 form-group">
                            <label htmlFor="pass">Create Password</label>
                            <input
                                type="Password"
                                name="password"
                                className="form-control"
                                id="pass"
                                placeholder="Enter your password."
                                required=""
                            />
                        </div>
                        <div className="col-sm-6 form-group">
                            <label htmlFor="pass2">Confirm Password</label>
                            <input
                                type="Password"
                                name="cnf-password"
                                className="form-control"
                                id="pass2"
                                placeholder="Re-enter your password."
                                required=""
                            />
                            <br />
                        </div>
                        <div className="col-sm-12">
                            <input
                                type="checkbox"
                                className="form-check d-inline"
                                id="chb"
                                required=""
                            />
                            <label htmlFor="chb" className="form-check-label">
                                &nbsp;I accept all terms and conditions.
                            </label>

                        </div>

                        <div className="main-red-button-hover"
                            style={{
                                // display: "inline-block" ,
                                textAlign: "right",
                                // backgroundColor :" #ff695f",
                                fontSize: "15px",
                                fontWeight: "400",
                                color: "#fff",
                                textTransform: "capitalize",
                                padding: "12px 25px",
                                borderRadius: "23px",
                                letterSpacing: "0.25px",
                                transition: "all .3s"
                            }}>
                            <a href="#contact">Submit</a>

                            <br />
                        </div>
                        <br />
                    </div>
                </form>
            </div>

            <ISFooter />
        </>
    )
}


