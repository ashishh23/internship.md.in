import React from "react";
import  ReactDOM from "react-dom"; 
import { BrowserRouter, Route, Routes } from "react-router-dom";
// import { BrowserRouter, Route, Routes, Link } from "react-router-dom";
import App from "./App.js";
import RegistrationForm from "./RegistrationForm";
import STLogin from "./stLogin.js";
import DashBord from "./dashBord"
import Ashish from "../src/components/MDteam/ashish"
import Swapnil from "../src/components/MDteam/swapnil"
ReactDOM.render(<BrowserRouter>
  <Routes>
      <Route path="/" element={<App />}></Route>
      <Route path="/RegistrationForm" element={<RegistrationForm />}></Route>
      <Route path="/STLogin" element={<STLogin />}></Route>
      <Route path="/DashBord" element={<DashBord />}></Route>
      <Route path="/ashish" element={<Ashish />}></Route>
      <Route path="/swapnil" element={<Swapnil />}></Route>
    

</Routes>
</BrowserRouter>
,
document.getElementById("root"))